string = "United_Kingdom"
print(string.replace("_","").lower().isalpha())