# BigData
Map Reduce implementation using RDD (Resilient Distributed Dataset) for analyzing the huge scale datasets
